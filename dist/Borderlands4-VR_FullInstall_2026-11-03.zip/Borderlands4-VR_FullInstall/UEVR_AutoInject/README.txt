UEVR AUTO INJECTOR - README
===========================

WHAT THIS IS
------------
UEVRAutoInject.exe is a Windows app that plays your Steam games in VR with UEVR,
without you having to juggle the injector by hand. It:

1. Scans your installed Steam games and lists the Unreal Engine ones.
2. Lets you pick which UEVR version to use for each game:
   - UEVR (official, by praydog)
   - UEVR Nightly (praydog's nightly builds)
   - UEVR joeyhodge fork (many fixes for newer UE 5.5 - 5.8 games)
   - UEVR AFW by PureDark (Alternate Frame Warping - big performance boost,
     DX12 games only)
   It downloads any of these from GitHub for you and tells you at startup
   when a newer build is out.
3. You set how many seconds to wait after launch, then press "Play in VR".
   The app launches the game through Steam, waits, then injects UEVR into the
   game process exactly the way the official UEVR injector does.

HOW TO USE
----------
1. Open UEVRAutoInject.exe (it lives in this folder).
2. Choose a game in the list on the left.
3. On the right, pick a UEVR version. Ones marked "download" will be fetched
   automatically the first time you use them. Ones marked "installed" are ready.
   Your existing folder "UEVR-joeyhodge_AFW_v1.0-beta.5" in this directory is
   detected automatically and shows up as an installed version.
4. Set the wait time in seconds (default 20). If a game crashes when injecting,
   try a longer wait so it gets past its intro movies first.
5. Press the big yellow "PLAY IN VR" button (or Ctrl+Enter).
6. Once injected, press the Insert key in game to open UEVR's own menu.

IMPORTING PROFILES
------------------
Press the "Import profile (F7)" button and choose a profile zip. The app
unzips it and stores it under the right game automatically, just like UEVR's
own Import Config button. Profiles live in one shared folder
(%APPDATA%\UnrealVRMod), and every UEVR version - official, Nightly,
joeyhodge and AFW - reads from that same folder, so you only import a
profile ONCE and all versions use it.
If a profile contains a DLL plugin, the app warns you first - only accept
DLLs from sources you trust.
"Open profiles folder (F8)" opens that shared folder in File Explorer.

KEYBOARD SHORTCUTS
------------------
F5          Rescan Steam games
F6          Check GitHub for UEVR updates
F7          Import a UEVR profile zip
F8          Open the shared profiles folder
Ctrl+Enter  Play the selected game in VR
Escape      Cancel a launch in progress

NOTES AND TIPS
--------------
- VR runtime: OpenXR is the default and best for most headsets. Switch a game
  to OpenVR (SteamVR) in its options if your setup needs SteamVR.
- AFW (Alternate Frame Warping) only supports DX12 games. Add -dx12 to the
  game's launch options in Steam if needed, and after injecting, enable AFW and
  the Ghosting Fix inside the UEVR menu (Insert key). The joeyhodge-based AFW
  build also wants the Bootstrap option ticked.
- Antivirus: injectors get flagged sometimes. If injection fails or files
  disappear, whitelist this folder in your antivirus (the official UEVR
  project gives the same advice).
- If the app says it cannot open the game process, it will offer to restart
  itself as administrator - say yes and try again.
- Every action is written to the activity log at the bottom of the window and
  to UEVRAutoInject.log in this folder.
- Per-game choices are remembered in settings.json in this folder. Downloaded
  UEVR versions go into the UEVR-Versions subfolder.

SOURCE CODE
-----------
The full source is in the "src" subfolder (C#, .NET 8, Windows Forms).
